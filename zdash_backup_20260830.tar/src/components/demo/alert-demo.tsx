import { useState } from "react"
import { Alert, AlertDescription, AlertTitle, AlertAction } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Info } from "lucide-react"

// --- Alert Component (shadcn spec: base-nova) ---

export function AlertDemo() {
  return (
    <div className="flex flex-col gap-6 p-6">
      {/* Basic */}
      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Heads up!</AlertTitle>
        <AlertDescription>
          You can add components and dependencies to your app using the CLI.
        </AlertDescription>
        <AlertAction>
          <Button variant="outline" size="sm">Enable</Button>
        </AlertAction>
      </Alert>

      {/* Destructive */}
      <Alert variant="destructive">
        <Info className="h-4 w-4" />
        <AlertTitle>Destructive action</AlertTitle>
        <AlertDescription>
          This will permanently delete your account and all associated data.
        </AlertDescription>
      </Alert>

      {/* Custom Colors */}
      <Alert className="bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800">
        <Info className="h-4 w-4 text-amber-600 dark:text-amber-400" />
        <AlertTitle className="text-amber-900 dark:text-amber-100">Custom Theme</AlertTitle>
        <AlertDescription className="text-amber-700 dark:text-amber-200">
          You can customize the alert colors by adding custom classes.
        </AlertDescription>
      </Alert>

      {/* Action variant */}
      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Storage almost full</AlertTitle>
        <AlertDescription>
          Your dashboard storage is at 92% capacity. Upgrade to get more space.
        </AlertDescription>
        <AlertAction>
          <Button variant="outline" size="sm">Upgrade Plan</Button>
        </AlertAction>
      </Alert>
    </div>
  )
}
