import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Calendar } from "@/components/ui/calendar"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip"
import {
  Message, MessageAvatar, MessageContent,
  MessageHeader, MessageFooter,
} from "@/components/ui/message"
import {
  TooltipProvider,
  Tooltip as TooltipPrimitive,
} from "@/components/ui/tooltip"
import { cn } from "@/lib/utils"
import {
  CalendarIcon, Mail, FileText, FolderOpen, Archive,
  Settings, Bell, LogOut, User, Plus, Send, Search,
  ChevronRight, Clock, CheckCircle, AlertCircle,
  Inbox, SendHorizontal, RefreshCw, Trash2, Reply,
  Star, MoreHorizontal, Paperclip, Image as ImageIcon,
  ScrollText, BarChart3, TrendingUp, Users, DollarSign,
  Activity, PieChart, MessageSquare, Hash, BookOpen,
  Layers, HardDrive, Briefcase, ExternalLink, Copy,
  Check, X, ChevronDown, Menu, XCircle, Loader2,
  Bookmark, Tag, Filter, SortAsc, SortDesc, Grid3X3,
  List, Eye, Edit3, Share2, Trash, Download, Upload,
} from "lucide-react"
import { useState, useRef } from "react"
